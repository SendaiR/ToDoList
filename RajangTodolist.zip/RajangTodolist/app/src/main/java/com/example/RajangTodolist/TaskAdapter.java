package com.example.RajangTodolist;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.RajangTodolist.R;

import java.util.List;

public class TaskAdapter extends ArrayAdapter<TodoEntity> {

    public TaskAdapter(@NonNull Context context, int resource, @NonNull List<TodoEntity> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_task, parent, false);
        }

        TextView textViewTask = convertView.findViewById(R.id.textViewTask);
        Button buttonEditTask = convertView.findViewById(R.id.buttonEditTask);
        Button buttonDeleteTask = convertView.findViewById(R.id.buttonDeleteTask);

        final TodoEntity todo = getItem(position);

        if (todo != null) {
            textViewTask.setText(todo.getTask());

            // Set listener untuk tombol edit
            buttonEditTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    editTask(todo);
                }
            });

            // Set listener untuk tombol delete
            buttonDeleteTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteTask(todo);
                }
            });
        }

        return convertView;
    }

    private void editTask(final TodoEntity todo) {
        final EditText editTextEditTask = new EditText(getContext());
        editTextEditTask.setText(todo.getTask());

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Edit Task")
                .setView(editTextEditTask)
                .setPositiveButton("Simpan", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String editedTask = editTextEditTask.getText().toString();
                        if (!editedTask.isEmpty()) {
                            todo.setTask(editedTask);
                            updateTask(todo);
                        }
                    }
                })
                .setNegativeButton("Batal", null)
                .show();
    }


    private void deleteTask(final TodoEntity todo) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Hapus Task")
                .setMessage("Apakah Anda yakin ingin menghapus task ini?")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteTaskFromDatabase(todo);
                    }
                })
                .setNegativeButton("Tidak", null)
                .show();
    }

    private void updateTask(final TodoEntity todo) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                TodoDatabase.getInstance(getContext()).todoDao().update(todo);
                ((Activity) getContext()).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        notifyDataSetChanged();
                    }
                });
            }
        });
    }

    private void deleteTaskFromDatabase(final TodoEntity todo) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                TodoDatabase.getInstance(getContext()).todoDao().delete(todo);
                ((Activity) getContext()).runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        remove(todo);
                    }
                });
            }
        });
    }
}
