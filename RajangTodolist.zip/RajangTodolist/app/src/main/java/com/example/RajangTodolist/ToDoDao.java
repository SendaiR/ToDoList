package com.example.RajangTodolist;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// TodoDao.java
@Dao
public interface ToDoDao {
    @Insert
    void insert(TodoEntity todo);

    @Update
    void update(TodoEntity todo);

    @Delete
    void delete(TodoEntity todo);

    @Query("SELECT * FROM todo_table")
    List<TodoEntity> getAllTasks();
}

