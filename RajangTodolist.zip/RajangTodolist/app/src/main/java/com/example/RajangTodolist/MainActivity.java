// MainActivity.java
package com.example.RajangTodolist;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.RajangTodolist.R;

import java.util.ArrayList;
import java.util.List;



public class MainActivity extends AppCompatActivity {

    private EditText editTextTask;
    private Button buttonAdd;
    private ListView listViewTasks;
    private TaskAdapter adapter;
    private ArrayList<TodoEntity> taskList;
    private TodoDatabase todoDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTask = findViewById(R.id.editTextTask);
        buttonAdd = findViewById(R.id.buttonAdd);
        listViewTasks = findViewById(R.id.listViewTasks);

        taskList = new ArrayList<>();
        adapter = new TaskAdapter(this, R.layout.list_item_task, taskList);
        listViewTasks.setAdapter(adapter);

        todoDatabase = TodoDatabase.getInstance(this);

        // Load tasks from the database
        loadTasks();
    }

    public void addTask(View view) {
        String task = editTextTask.getText().toString();
        if (!task.isEmpty()) {
            TodoEntity todo = new TodoEntity(task);
            insertTask(todo);
            editTextTask.getText().clear();
        }
    }

    private void insertTask(final TodoEntity todo) {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                todoDatabase.todoDao().insert(todo);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        loadTasks();
                    }
                });
            }
        });
    }

    private void loadTasks() {
        AsyncTask.execute(new Runnable() {
            @Override
            public void run() {
                final List<TodoEntity> tasks = todoDatabase.todoDao().getAllTasks();
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        taskList.clear();
                        taskList.addAll(tasks);
                        adapter.notifyDataSetChanged();
                    }
                });
            }
        });
    }
}
