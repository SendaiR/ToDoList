package com.example.RajangTodolist;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// TodoEntity.java
@Entity(tableName = "todo_table")
public class TodoEntity {
    @PrimaryKey (autoGenerate = true)
    private int id;

    @ColumnInfo (name = "task")
    private String task;

    public TodoEntity(String task) {
        this.task = task;
    }

    public int getId() {
        return id;
    }

    public String getTask() {
        return task;
    }

    public void setId(int id) {
        this.id = id;
    }
    public void setTask(String task) {
        this.task = task;
    }
}

